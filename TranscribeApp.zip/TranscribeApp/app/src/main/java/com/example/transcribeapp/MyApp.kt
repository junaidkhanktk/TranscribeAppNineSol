package com.example.transcribeapp

import android.app.Application
import com.example.transcribeapp.koin.allModules
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.GlobalContext.startKoin
import timber.log.Timber


class MyApp : Application() {

    override fun onCreate() {
        super.onCreate()

        Timber.plant(Timber.DebugTree())
        startKoin {
            androidContext(this@MyApp)
            modules(listOf(allModules))
        }
    }
}