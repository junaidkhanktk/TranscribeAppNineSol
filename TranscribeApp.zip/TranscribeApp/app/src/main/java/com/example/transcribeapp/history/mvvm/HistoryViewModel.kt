package com.example.transcribeapp.history.mvvm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.transcribeapp.history.History
import com.example.transcribeapp.history.HistoryDataBase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class HistoryViewModel(application: Application) :
    AndroidViewModel(application) {

    private val historyDao = HistoryDataBase.getDataBase(application).historyDao()
    private val repository = HistoryRepo(historyDao)



    val readHistory: LiveData<List<History>> = repository.readHistory



    fun insertHistory(history: History) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertHistory(history)
        }
    }

    fun deleteHistory(history: History) {

        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteHistory(history)
        }
    }


}


