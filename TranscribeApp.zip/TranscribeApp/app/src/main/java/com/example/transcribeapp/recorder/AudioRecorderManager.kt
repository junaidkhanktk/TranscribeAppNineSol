package com.example.transcribeapp.recorder

import android.content.Context
import android.media.MediaRecorder
import android.os.Environment
import androidx.appcompat.app.AppCompatActivity
import com.example.transcribeapp.activities.VoskActivity
import com.example.transcribeapp.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

class AudioRecorderManager(private val context: Context):AppCompatActivity(),TimeHandler.OnTimerUpdateListener {

  // var fileName: String =  "${context.cacheDir.absolutePath}/audioRecord.wav"
   var fileName: String =  generateFileName()
    private var recorder: MediaRecorder? = null
    private var timeHandler: TimeHandler? = null
    var recording = false
     var onPause = false
    private lateinit var audioFile: File


   fun resumeRecording() {
        onPause = false
       // binding.stopRecBtn.beInvisible()
        recorder?.apply {
            resume()
        }
       // binding.recordBtn.setImageResource(R.drawable.stop_rec_icon)
       // animatePlayerView()
        timeHandler?.start()
    }
     fun pauseRecording() {
       // binding.stopRecBtn.beVisible()
        onPause = true
        recorder?.pause()
      //  binding.recordBtn.setImageResource(R.drawable.start_rec_icon)
        timeHandler?.pause()

    }
   fun startRecording() {
       fileName = generateFileName()
        recording = true
        timeHandler = TimeHandler(this)
        timeHandler?.start()
        recorder = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(fileName)
            try {
                prepare()
                start()
            } catch (e: IOException) {
                e.printStackTrace()
            } catch (e: RuntimeException) {
                e.printStackTrace()
            }

        }
       // binding.recordBtn.setImageResource(R.drawable.stop_rec_icon)
       // animatePlayerView()
    }

     fun stopRecording() {
        recording = false
        onPause = false
        recorder?.apply {
            stop()
            release()
        }
        recorder = null
      //  binding.recordBtn.setImageResource(R.drawable.start_rec_icon)
       // binding.recorderWaveformView.reset()
        try {
            timeHandler?.stop()
        } catch (e: Exception) {
            e.printStackTrace()
        }
       // binding.timerView.text = getString(R.string.time)
        audioFile = File(fileName)
        audioFile.parentFile?.let { parent ->
            if (!parent.exists()) {
                parent.mkdir()

            }
        }

        if (!audioFile.exists()) {
            try {
                audioFile.createNewFile()
            } catch (e: java.lang.Exception) {
               // "error :${e.message}".log()
            }
        }

    }


    override fun onTimerUpdate(duration: String) {

      /*  CoroutineScope(Dispatchers.Main).launch {
            if (recording)
                //binding.timerView.text = duration
        }*/
    }


    private fun generateFileName(): String {
        val timestamp = System.currentTimeMillis()
        return "${context.cacheDir.absolutePath}/audioRecord_$timestamp.wav"
    }

}