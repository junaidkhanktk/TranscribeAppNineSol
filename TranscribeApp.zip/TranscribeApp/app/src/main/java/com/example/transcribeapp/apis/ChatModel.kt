package com.example.transcribeapp.apis


data class ChatModel(val message:String?=null, val response: String?=null)
