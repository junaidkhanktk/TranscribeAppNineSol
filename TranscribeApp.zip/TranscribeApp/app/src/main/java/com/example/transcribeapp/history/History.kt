package com.example.transcribeapp.history

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "history_table",
   // indices = [Index(value = ["title"], unique = true)]
)
data class History(
    val title: String,
    val text: String,
    val date: String,
    val audioPath: String,
    ) {
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0
}


