package com.example.transcribeapp.recorder

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.example.transcribeapp.databinding.ActivityMainBinding
import java.util.Locale

class SpeechRecognitionManager(
    val context: Context,
    private var binding: ActivityMainBinding,
) {
    var isRecording = false
    var isListening = false
    var conversationList = mutableListOf<String>()
    var fullText = ""

    private val speechRecognizer: SpeechRecognizer =
        SpeechRecognizer.createSpeechRecognizer(context)
    private val speechRecognizerIntent: Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

    init {
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(bundle: Bundle) {
                isListening = true
            }

            override fun onBeginningOfSpeech() {
                /*   binding.userInput.hint = context.getString(R.string.listening)
                   binding.startSpeaking.beInvisible()
                   binding.stopSpeaking.beVisible()*/
            }

            override fun onRmsChanged(v: Float) {}

            override fun onBufferReceived(bytes: ByteArray) {}

            override fun onEndOfSpeech() {
                isListening = false
                /*if (isRecording) {
                    startListening() // Restart listening immediately
                }*/

                startListening() // Restart listening immediately
            }

            override fun onError(error: Int) {
                Log.d("SpeachError", "onError: ${error.toString()}")


                /*  Log.d("onError", "onError: ${error.inv()}")
                  Log.d("onError", "onError: ${error.inc()}")
                  Log.d("onError", "onError: ${error.dec()}")*/
                isListening = false
                /* if (isRecording) {
                     startListening() // Restart listening immediately
                 }*/
                startListening() // Restart listening immediately
            }

            override fun onResults(bundle: Bundle) {
                val data = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!data.isNullOrEmpty()) {
                    val newText = data[0]
                    fullText += " $newText"
                    conversationList.add(newText)
//                    binding.myTextView.text = fullText.trim()
                }
                isListening = false

                startListening() // Restart listening immediately

            }

            override fun onPartialResults(bundle: Bundle) {
                val partialResults = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!partialResults.isNullOrEmpty()) {
                    Log.d("onPartialResults", "onPartialResults: $partialResults")
                    val partialText = partialResults[0]
//                    binding.myTextView.text = "$fullText $partialText".trim()
                }
            }

            override fun onEvent(i: Int, bundle: Bundle) {}
        })
    }

    fun destroy() {
        speechRecognizer.destroy()
    }

    fun startListening() {
        if (!isListening) {
            isRecording = true
//            binding.startStopButton.text = "Stop Recording"
            speechRecognizer.startListening(speechRecognizerIntent)
        }
    }

    fun stopListening() {
        isRecording = false
        speechRecognizer.stopListening()
//        binding.startStopButton.text = "Start Recording"
    }
}
