package com.example.transcribeapp.activities

import android.Manifest
import android.animation.ObjectAnimator
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.transcribeapp.R
import com.example.transcribeapp.databinding.ActivityMainBinding
import com.example.transcribeapp.extension.startNewActivity
import com.example.transcribeapp.history.History
import com.example.transcribeapp.recorder.AudioRecorderManager
import com.example.transcribeapp.recorder.SpeechRecognitionManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.File
import java.io.IOException
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class MainActivity : AppCompatActivity() {


    private val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }


    // private lateinit var speechRecognitionManager: SpeechRecognitionManager
    // private lateinit var audioRecorderManger: AudioRecorderManager
    private lateinit var audioRecorderManger: AudioRecorderManager
    private lateinit var speechService: SpeechService

    private var isRecording = false

    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        binding.bottomNavigation.setupWithNavController(navController)

        binding.bottomNavigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.idHomeFragment -> {
                    navController.navigate(R.id.idHomeFragment)
                    true
                }
                R.id.idAiFragment -> {
                    navController.navigate(R.id.idAiFragment)
                    true
                }
                R.id.idCalenderFragment -> {
                    navController.navigate(R.id.idCalenderFragment)
                    true
                }
                else -> false
            }
        }
      //  setupActionBarWithNavController(navController)

//
//        // Check and request for microphone permission
//        if (ContextCompat.checkSelfPermission(
//                this,
//                Manifest.permission.RECORD_AUDIO
//            ) != PackageManager.PERMISSION_GRANTED
//        ) {
//            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
//        } else {
//
//            audioRecorderManger = AudioRecorderManager(this )
//            initVosk()
//
//        }
//
//        binding.history.setOnClickListener {
//            startNewActivity<HistoryActivity>()
//        }
//
//        binding.startStopButton.setOnClickListener {
//            startListeningv()
//            lifecycleScope.launch(Dispatchers.IO) {
//                when {
//                    audioRecorderManger.onPause -> audioRecorderManger.resumeRecording()
//                    audioRecorderManger.recording -> audioRecorderManger.pauseRecording()
//                    else -> audioRecorderManger.startRecording()
//                }
//            }
//        }
//
//        binding.saveRecording.setOnClickListener {
//            audioRecorderManger.stopRecording()
//            stopListening()
//            //saveConversationToFile()
//            binding.timerView.text = "00:00:00"
//
//            lifecycleScope.launch(Dispatchers.IO) {
//                val formatter = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
//                val date = Date()
//                val history = History(
//                    "First",
//                    binding.myTextView.text.trim().toString(),
//                    formatter.format(date),
//                    audioRecorderManger.fileName
//                )
//                historyViewModel.insertHistory(history)
//            }
//
//        }
    }
    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }

//    override fun onRequestPermissionsResult(
//        requestCode: Int,
//        permissions: Array<out String>,
//        grantResults: IntArray
//    ) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//            initVosk()
//        }
//    }


//    private fun initVosk() {
//        StorageService.unpack(this, "model-en-us", "model",
//            { model: Model? ->
//                speechService = SpeechService(Recognizer(model, 8000f), 8000.0f)
//                // speechService.setListener()
//
//            },
//            { exception: IOException ->
//                exception.printStackTrace()
//                Log.d("TAG", "onError:${exception?.message} ")
//            })
//    }
//
//
//    private fun startListeningv() {
//        if (::speechService.isInitialized) {
//            isRecording = true
//            binding.startStopButton.text = "Stop Recording"
//            // startStopButton.text = "Stop Recording"
//            speechService.startListening(this)
//        }
//    }
//
//    private fun stopListening() {
//        if (::speechService.isInitialized) {
//            isRecording = false
//            binding.startStopButton.text = "Start Recording"
//            speechService.stop()
//        }
//    }
//
//
//    /*    private fun saveConversationToFile() {
//            val fileName = "conversation_${System.currentTimeMillis()}.txt"
//            val file = File(filesDir, fileName)
//            Log.d("pathoffile", "saveConversationToFile: $file")
//            Log.d("pathoffile", "saveConversationToFile: $fileName")
//            try {
//                file.writeText(speechRecognitionManager.conversationList.joinToString("\n"))
//                Toast.makeText(this, "Conversation saved to $fileName", Toast.LENGTH_SHORT).show()
//            } catch (e: Exception) {
//                Toast.makeText(this, "Error saving conversation: ${e.message}", Toast.LENGTH_SHORT)
//                    .show()
//            }
//        }*/
//
//    override fun onDestroy() {
//        super.onDestroy()
//        // speechRecognitionManager.destroy()
//    }
//
//    override fun onPartialResult(hypothesis: String?) {
//        binding.myTextView.text = hypothesis
//    }
//
//    override fun onResult(hypothesis: String?) {
//        binding.myTextView.text = hypothesis
//    }
//
//    override fun onFinalResult(hypothesis: String?) {
//        binding.myTextView.text = hypothesis
//    }
//
//    override fun onError(exception: Exception?) {
//        Log.d("TAG", "onError:${exception?.message} ")
//    }
//
//    override fun onTimeout() {
//        Log.d("TAG", "TimeOut ")
//
//    }
}

