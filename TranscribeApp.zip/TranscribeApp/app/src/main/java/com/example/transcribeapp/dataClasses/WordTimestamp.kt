package com.example.transcribeapp.dataClasses

//data class WordTimestamp(val word: String, val startTimeMs: Long, val endTimeMs: Long, val indices: List<Int>)
data class WordTimestamp(val word: String, val startTimeMs: Long, val endTimeMs: Long)
