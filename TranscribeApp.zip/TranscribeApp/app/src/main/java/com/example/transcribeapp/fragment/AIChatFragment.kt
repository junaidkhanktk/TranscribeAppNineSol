package com.example.transcribeapp.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.transcribeapp.R
import com.example.transcribeapp.databinding.FragmentAIChatBinding

class AIChatFragment : BaseFragment<FragmentAIChatBinding>(FragmentAIChatBinding::inflate) {


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }
}