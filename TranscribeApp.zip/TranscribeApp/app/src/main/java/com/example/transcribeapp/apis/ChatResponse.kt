package com.example.transcribeapp.apis

/**
 * @Author: Naveed Ur Rehman
 * @Designation: Android Developer
 * @Date: 04/07/2024
 * @Gmail: naveedurrehman.ninesol@gmail.com
 * @Company: Ninesol Technologies
 */
