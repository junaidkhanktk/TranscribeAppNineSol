package com.example.transcribeapp.extension

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import timber.log.Timber

fun String.log(logLevel: Int = Log.DEBUG, tag: String = "TESTING") {
    when (logLevel) {
        Log.VERBOSE -> Timber.tag(tag).v(this)
        Log.DEBUG -> Timber.tag(tag).d(this)
        Log.INFO -> Timber.tag(tag).i(this)
        Log.WARN -> Timber.tag(tag).w(this)
        Log.ERROR -> Timber.tag(tag).e(this)
        Log.ASSERT -> Timber.tag(tag).wtf(this)
    }
}



inline fun <reified A : Activity> Context.startNewActivity() {
    this.startActivity(Intent(this, A::class.java))
}

fun Context.showToast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

 fun String.indicesOf(word: String): List<Int> {
    val indices = mutableListOf<Int>()
    var index = this.indexOf(word)
    while (index >= 0) {
        indices.add(index)
        index = this.indexOf(word, index + word.length)
    }
    return indices
}