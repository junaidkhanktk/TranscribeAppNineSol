package com.example.transcribeapp.recorder

import java.util.Timer
import java.util.TimerTask

class TimeHandler(private var listener: OnTimerUpdateListener) {

    interface OnTimerUpdateListener{
        fun onTimerUpdate(duration: String)
    }

    private var duration : Long = 0
    private var period : Long = 258
    private lateinit var timer : Timer

    fun start(){
        timer = Timer()
        timer.schedule(object : TimerTask(){
            override fun run() {
                duration += period
                listener.onTimerUpdate(format())
            }
        },period, period)
    }


    fun pause(){
        timer.cancel()
    }


    fun stop() {
        timer.cancel()
        timer.purge()
    }

    fun getDuration(): Long{return duration}

    fun format(): String {
        val milli = duration % 1000
        val seconds = (duration / 1000) % 60
        val minutes = (duration / (1000 * 60) % 60)
        val hours = (duration / (1000 * 60 * 60) % 24)

        return if (hours > 0)
            "%02d:%02d:%02d.%02d".format(hours, minutes, seconds, milli / 10)
        else
            "%02d:%02d.%02d".format(minutes, seconds, milli / 10)
    }
}